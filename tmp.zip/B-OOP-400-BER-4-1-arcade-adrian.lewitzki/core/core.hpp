/*
** EPITECH PROJECT, 2019
** FILE_NAME
** File description:
** FILE DESCRIPTION
*/

#ifndef B_OOP_400_BER_4_1_ARCADE_ADRIAN_LEWITZKI_CORE_HPP
#define B_OOP_400_BER_4_1_ARCADE_ADRIAN_LEWITZKI_CORE_HPP

#include <string>
#include <iostream>
#include <dlfcn.h>
#include <dirent.h>

#endif //B_OOP_400_BER_4_1_ARCADE_ADRIAN_LEWITZKI_CORE_HPP
