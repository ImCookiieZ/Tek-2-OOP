/*
** EPITECH PROJECT, 2021
** B_OOP_400_BER_4_1_arcade_adrian_lewitzki
** File description:
** ncurses.hpp
*/

#ifndef B_OOP_400_BER_4_1_ARCADE_ADRIAN_LEWITZKI_NCURSES_HPP
#define B_OOP_400_BER_4_1_ARCADE_ADRIAN_LEWITZKI_NCURSES_HPP

#include "../IGraphics.hpp"


class ncurses final : public IGraphics
{
private:
    int _width = 0;
    int _height = 0;
    bool _isValidWindow = true;
    std::vector<object_creation_data> _objects;
    static void changeColor(const std::string& color) ;
    static void reset_color();
    bool check_window_size();
public:
    void init_screen(int width, int height) final;
    void *createObject(void *object_data) final;
    void draw(void *object, int x0, int x1, int y0, int y1) final;
    void deleteObject(void *object) final;
    std::string getPressedKey(void) final;
    void close_screen() final;
    void display_screen() final;
    void clear_screen() final;
//    std::vector<object_creation_data> getObjectData() final;
};

extern "C" {
    IGraphics *create_graphics();
}

#endif //B_OOP_400_BER_4_1_ARCADE_ADRIAN_LEWITZKI_NCURSES_HPP
