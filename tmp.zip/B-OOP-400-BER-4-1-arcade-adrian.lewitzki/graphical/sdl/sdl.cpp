/*
** EPITECH PROJECT, 2019
** FILE_NAME
** File description:
** FILE DESCRIPTION
*/

#include "sdl.hpp"

extern "C" {
IGraphics *create_graphics() {
    return new sdl;
}
}


static SDL_Color black {
        .r = 0,
        .g = 0,
        .b = 0,
        .a = 0
};

static SDL_Color white {
    .r = 255,
    .g = 255,
    .b = 255,
    .a = 0
};

static SDL_Color red {
        .r = 255,
        .g = 0,
        .b = 0,
        .a = 0
};

static SDL_Color green {
        .r = 0,
        .g = 255,
        .b = 0,
        .a = 0
};

static SDL_Color yellow {
        .r = 255,
        .g = 255,
        .b = 0,
        .a = 0
};

static SDL_Color blue {
        .r = 0,
        .g = 0,
        .b = 255,
        .a = 0
};

static SDL_Color cyan {
        .r = 0,
        .g = 255,
        .b = 255,
        .a = 0
};

static SDL_Color magenta {
        .r = 255,
        .g = 0,
        .b = 255,
        .a = 0
};

void sdl::init_screen(int width, int height) {
    SDL_Init(SDL_INIT_EVERYTHING);
    TTF_Init();
    _window = SDL_CreateWindow\
    ("Arcade", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, width, height, SDL_WINDOW_SHOWN);
    _renderer = SDL_CreateRenderer(_window, -1, 0);
    clear_screen();
    display_screen();
    _colors = {
            {"black", black},
            {"white", white},
            {"red", red},
            {"green", green},
            {"yellow", yellow},
            {"blue", blue},
            {"cyan", cyan},
            {"magenta", magenta}
    };


    //---------------------------

    /*

    clear_screen();
    TTF_Init();
    SDL_Color color = {255, 255, 255};
    TTF_Font *sans = TTF_OpenFont("assets/font.ttf", 24);
    SDL_Surface *tmpSurface = TTF_RenderText_Solid(sans, "fuckkk", color);

    SDL_Texture *texture = SDL_CreateTextureFromSurface(_renderer, tmpSurface);
    SDL_Rect rect;
    rect.x = 0;
    rect.y = 0;
    rect.w = 100;
    rect.h = 100;
    SDL_RenderCopy(_renderer, texture, nullptr, &rect);
    SDL_FreeSurface(tmpSurface);
    display_screen();

    while(1);
     */

}

void *sdl::createObject(void *object_data) {
    object_creation_data *data = static_cast<object_creation_data *>(object_data);
    Obj obj = {};

    // muss alpha code checken, weil 0 ist eigentlich falsch, bei text aber nicht

    _objects.emplace_back(*data);

    if (data->type == SPRITE || data->type == TEXT) {
        SDL_Color color = getColor(data);
        SDL_Surface *tmpSurface;

        if (data->type == SPRITE) {
            tmpSurface = IMG_Load(data->path_to_resource.c_str());
        } else {
            //"assets/font.ttf"
            TTF_Font *font = TTF_OpenFont(data->path_to_resource.c_str(), 44);
            tmpSurface = TTF_RenderText_Solid(font, data->text.c_str(), color);
            TTF_CloseFont(font);
        }
        obj.texture = SDL_CreateTextureFromSurface(_renderer, tmpSurface);
        obj.data = data;
        obj.height = tmpSurface->h;
        obj.width = tmpSurface->w;
        SDL_FreeSurface(tmpSurface);
        /*
        if (data->type == SPRITE) {
            SDL_SetTextureColorMod(obj.texture, color.r, color.g, color.b);
            SDL_SetTextureAlphaMod(obj.texture, color.a);
        }
         */
        _sprites.emplace_back(obj);
    }
    return data;
}

void sdl::draw(void *object, int x0, int x1, int y0, int y1) {
    object_creation_data *data = static_cast<object_creation_data *>(object);
    SDL_Rect rect = {x0, y0, x1 - x0, y1 - y0};
    //SDL_Rect rect = {x0, y0, 300, 50};

    if (data->type == SPRITE || data->type == TEXT) {
        size_t i = 0;
        for (; i < _sprites.size(); i++) {
            if (data == _sprites[i].data) {
                if (data->type == TEXT) {
                    rect.w = _sprites[i].width;
                    rect.h = _sprites[i].height;
                }
                SDL_RenderCopy(_renderer, _sprites[i].texture, nullptr, &rect);
                break;
            }
        }
        if (i == _sprites.size()) {
            createObject(data);
            draw(data, x0, x1, y0, y1);
            return;
        }
    } else {
        // -> must be rect
        SDL_Color color = getColor(data);
        SDL_SetRenderDrawColor(_renderer, color.r, color.g, color.b, color.a);
        //SDL_RenderDrawRect(_renderer, &rect); -> draw outline
        SDL_RenderFillRect(_renderer, &rect);
    }
}

void sdl::deleteObject(void *object) {
    object_creation_data *data = static_cast<object_creation_data *>(object);

    for (size_t i = 0; i < _objects.size(); i += 1) {
        if (&_objects[i] == data) {
            _objects.erase(_objects.begin() + i);
            break;
        }
    }
    for (size_t i = 0; i < _sprites.size(); i += 1) {
        if (_sprites[i].data == data) {
            SDL_DestroyTexture(_sprites[i].texture);
            _sprites.erase(_sprites.begin() + i);
            break;
        }
    }
}

std::string sdl::getPressedKey() {
    while (SDL_PollEvent(&_event)) {
        if (_event.type == SDL_QUIT || \
        (_event.type == SDL_WINDOWEVENT && _event.window.event == SDL_WINDOWEVENT_CLOSE))
            return "exit";
        else if (_event.type == SDL_KEYDOWN) {
            switch (_event.key.keysym.sym) {
                case SDLK_ESCAPE:
                    return "esc";
                case SDLK_RETURN:
                    return "enter";
                case SDLK_SPACE:
                    return "space";
                case SDLK_BACKSPACE:
                    return "backspace";
                case SDLK_TAB:
                    return "tab";
                case SDLK_UP:
                    return "up";
                case SDLK_LEFT:
                    return "left";
                case SDLK_RIGHT:
                    return "right";
                case SDLK_DOWN:
                    return "down";
                case 'o':
                    return "prev_g";
                case 'p':
                    return "next_g";
                default:
                    if ((_event.key.keysym.sym >= '0' && _event.key.keysym.sym <= '9') || \
                        (_event.key.keysym.sym >= 'a' && _event.key.keysym.sym <= 'z'))
                        return std::string(1, _event.key.keysym.sym);
                    return "*";
            }
        }
    }
    return "";
}

void sdl::close_screen() {
    auto it1 = _objects.begin();
    while (it1 != _objects.end())
        it1 = _objects.erase(it1);

    for (auto & _sprite : _sprites)
        SDL_DestroyTexture(_sprite.texture);
    auto it2 = _sprites.begin();
    while (it2 != _sprites.end())
        it2 = _sprites.erase(it2);

    SDL_DestroyWindow(_window);
    SDL_DestroyRenderer(_renderer);
    TTF_Quit();
    SDL_Quit();
}

void sdl::clear_screen() {
    SDL_RenderClear(_renderer);
}

void sdl::display_screen() {
    SDL_RenderPresent(_renderer);
}
//
//std::vector<object_creation_data> sdl::getObjectData() {
//    return _objects;
//}

SDL_Color sdl::getColor(object_creation_data *data) {
    SDL_Color color = white;

    std::string colorName = data->color_name;
    auto it = std::find_if(_colors.begin(), _colors.end(), \
    [&colorName](const std::pair<std::string, SDL_Color> &pair) {
        return pair.first == colorName;
    });
    if (it != _colors.end())
        color = it->second;
    return color;
}
