/*
** EPITECH PROJECT, 2019
** FILE_NAME
** File description:
** FILE DESCRIPTION
*/

#include "Solarfox.hpp"
#include <utility>

extern "C" {
IGame *create_game(IGraphics *lib) {
    return new Solarfox(lib);
}
}

Solarfox::Solarfox(IGraphics *lib) : lib(lib)
{
}

void Solarfox::start_game()
{
    lib->init_screen(1920, 1080);
    _name = *fill_data("", TEXT, "assets/font.ttf", "red");
    _isRunning = false;
    std::ifstream os;
    os.open("users");
    if (os.is_open())
        getline(os, _name.text);
    _name.text = "name: " + _name.text;
    os.close();

    std::ifstream is;
    is.open("solarfox_scores");
    if (is.is_open()) {
        std::string line;
        while (getline(is, line)) {
            std::stringstream tmp(line);
            std::string sc;
            std::string na;
            tmp >> na >> sc;
            try {
                std::pair<std::string, int> tpair{na, stoi(sc)};
                _scores.emplace_back(tpair);
            } catch (std::exception &) {}
        }
    }
    create_borders();
    create_grid();
    create_player();
    create_enemies();
    _objects.insert(std::pair<std::string, std::vector<object_triple>>
    ("enemy_projectiles", std::vector<object_triple>()));
}

std::string Solarfox::game_tick()
{
    _input += lib->getPressedKey();

    if (_input.find("exit") != std::string::npos) {
        lib->destroy_screen();
        return "exit";
    }
    if (_input.find("enter") != std::string::npos)
        lib->destroy_screen();
    /*if (!_isRunning) {
        gameover();
        return _input;
    }*/
    std::chrono::steady_clock::time_point t = std::chrono::steady_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::microseconds>(t -
        _last_tick).count();
    if (elapsed > 100000) {
        get_move();
        move_player();
        move_enemies();
        _last_tick = t;
        _input.clear();
    }
    lib->clear_screen();
    for (auto &object : _objects["border"]) {
        lib->draw(object.third, object.second.x1, object.second.x2, object
            .second.y1, object.second.y2);
    }
    for (auto &object : _objects["grid"]) {
        lib->draw(object.third, object.second.x1, object.second.x2, object
            .second.y1, object.second.y2);
    }
    for (auto &object : _objects["enemies"]) {
        lib->draw(object.third, object.second.x1, object.second.x2, object
            .second.y1, object.second.y2);
    }
    lib->draw(_player.third, _player.second.x1, _player.second.x2, _player
        .second.y1, _player.second.y2);
    lib->display_screen();
    return _input;
}

bool Solarfox::is_running()
{
    return _isRunning;
}

void Solarfox::use_graphics_lib(IGraphics *lib)
{
    lib = lib;
}

void Solarfox::reload_all_objects()
{
}

void Solarfox::gameover()
{
    object_creation_data *tmp = fill_data("Game Over",
TEXT, "assets/font.ttf", "red");
    void *tmp_obj = lib->createObject(tmp);
    lib->clear_screen();
    lib->draw(tmp_obj, 200, 200, 500, 500);

    object_creation_data *tmp2 = fill_data("Press enter to restart", TEXT,
"assets/font.ttf", "green");
    void *tmp_obj2 = lib->createObject(tmp2);
    lib->draw(tmp_obj2, 200, 200, 560, 560);
}

void Solarfox::create_borders()
{
    object_creation_data *border_data = fill_data("x", SPRITE,
                                                  "assets/block_snake.png",
                                            "white");
    void *border_obj = lib->createObject(border_data);
    std::vector<object_triple> tmp_vec;
    for (int x = border.x1; x <= border.x2; x += 10)
    {
        pos tmp1 = {x, (x + 10), border.y1, (border.y1 + 20)};
        pos tmp2 = {x, (x + 10), border.y2, (border.y2 + 20)};
        tmp_vec.emplace_back(*create_triple(border_data, tmp1, border_obj));
        tmp_vec.emplace_back(*create_triple(border_data, tmp2, border_obj));
    }
    for (int y = border.y1; y <= border.y2; y += 10)
    {
        pos tmp1 = {border.x1, border.x1 + 10, y, y + 20};
        pos tmp2 = {border.x2, border.x2 + 10, y, y + 20};
        tmp_vec.emplace_back(*create_triple(border_data, tmp1, border_obj));
        tmp_vec.emplace_back(*create_triple(border_data, tmp2, border_obj));
    }
    _objects.insert(std::pair<std::string, std::vector<object_triple>>("border", tmp_vec));
}

object_creation_data *
Solarfox::fill_data(std::string text, object_type type, std::string path,
                    std::string color)
                    {
    object_creation_data *data = new object_creation_data;
    data->text = std::move(text);
    data->type = type;
    data->path_to_resource = std::move(path);
    data->color_name = std::move(color);
    return data;
}

void Solarfox::create_grid()
{
    object_creation_data *vertical_data = fill_data("|", SPRITE,
                                              "assets/block_snake.png", "white");
    void *vertical = lib->createObject(vertical_data);
    object_creation_data *horizontal_data = fill_data("-", SPRITE,
                                                "assets/block_snake.png", "white");
    void *horizontal = lib->createObject(horizontal_data);
    std::vector<object_triple> tmp_vec;
    for (int y = border.y1 + 100; y < border.y2; y += 80) {
        for (int x = border.x1 + 10; x < border.x2; x += 10) {
        pos tmp = {x, x + 10, y, y + 20};
        tmp_vec.emplace_back(*create_triple(horizontal_data, tmp, horizontal));
        }
    }
    for (int x = border.x1 + 100; x < border.x2; x += 80) {
        for (int y = border.y1 + 20; y < border.y2; y += 10) {
            pos tmp = {x, x + 10, y, y + 20};
            tmp_vec.emplace_back(*create_triple(vertical_data, tmp, vertical));
        }
    }
    _objects.insert(std::pair<std::string, std::vector<object_triple>>("grid",
        tmp_vec));
}

object_triple *
Solarfox::create_triple(object_creation_data *data, pos position, void *
object) {
    object_triple *t = new object_triple;
    t->first = *data;
    t->second = position;
    t->third = object;
    return t;
}

void Solarfox::create_player()
{
    object_creation_data *player_data = fill_data("x", SPRITE,
                                                    "assets/block_snake.png",
                                                    "blue");
    pos player_pos = {520, 540, 520, 540};
    void *player_obj = lib->createObject(player_data);
    _player = *create_triple(player_data, player_pos, player_obj);
}

void Solarfox::move_player()
{
    _player.second.x1 += _move_vec.first * 10;
    _player.second.x2 += _move_vec.first * 10;
    _player.second.y1 += _move_vec.second * 10;
    _player.second.y2 += _move_vec.second * 10;
}

void Solarfox::get_move()
{
    if (_input.find("right") != std::string::npos && _cur_direction != LEFT)
        _next_direction = RIGHT;
    if (_input.find("left") != std::string::npos && _cur_direction != RIGHT)
        _next_direction = LEFT;
    if (_input.find("up") != std::string::npos && _cur_direction != DOWN)
        _next_direction = UP;
    if (_input.find("down") != std::string::npos && _cur_direction != UP)
        _next_direction = DOWN;
    check_area();
    _input.clear();
    if (_cur_direction == UP)
    {
        _move_vec.first = 0;
        _move_vec.second = -1;
    }
    else if (_cur_direction == DOWN)
    {
        _move_vec.first = 0;
        _move_vec.second = 1;
    }
    else if (_cur_direction == RIGHT)
    {
        _move_vec.first = 1;
        _move_vec.second = 0;
    }
    else if (_cur_direction == LEFT)
    {
        _move_vec.first = -1;
        _move_vec.second = 0;
    }
}

void Solarfox::check_area()
{
    for (auto &object : _objects["grid"]) {
        if (_cur_direction == LEFT || _cur_direction == RIGHT) {
            if (object.first.text == "|" && object.second.x1 == _player
            .second.x1 && object.second.y1 == _player.second.y1)
                _cur_direction = _next_direction;
        }
        if (_cur_direction == UP || _cur_direction == DOWN) {
            if (object.first.text == "-" && object.second.x1 == _player
                .second.x1 && object.second.y1 == _player.second.y1)
                _cur_direction = _next_direction;
        }
    }
    if (_player.second.x1 <= 120 || _player.second.x1 >= 880 || _player
    .second.y1 <= 120 || _player.second.y1 >= 780)
        _isRunning = false;
}

void Solarfox::create_enemies()
{
    object_creation_data *enemy_data = fill_data("x", SPRITE,
                                                  "assets/block_snake.png",
                                                  "red");
    void *enemy_obj = lib->createObject(enemy_data);
    pos pos1 = {500, 520, 100, 120};
    pos pos2 = {500, 520, 800, 820};
    pos pos3 = {100, 120, 500, 520};
    pos pos4 = {900, 920, 500, 520};
    std::vector<object_triple> tmp_vec;

    tmp_vec.emplace_back(*create_triple(enemy_data, pos1, enemy_obj));
    tmp_vec.emplace_back(*create_triple(enemy_data, pos2, enemy_obj));
    tmp_vec.emplace_back(*create_triple(enemy_data, pos3, enemy_obj));
    tmp_vec.emplace_back(*create_triple(enemy_data, pos4, enemy_obj));
    _objects.insert(std::pair<std::string, std::vector<object_triple>>("enemies",
        tmp_vec));
    _move_enemy.emplace_back(1);
    _move_enemy.emplace_back(-1);
    _move_enemy.emplace_back(1);
    _move_enemy.emplace_back(-1);
}

void Solarfox::move_enemies()
{
    _objects["enemies"][0].second.x1 += _move_enemy[0] * 10;
    _objects["enemies"][0].second.x2 += _move_enemy[0] * 10;
    _objects["enemies"][1].second.x1 += _move_enemy[1] * 10;
    _objects["enemies"][1].second.x2 += _move_enemy[1] * 10;
    _objects["enemies"][2].second.y1 += _move_enemy[2] * 10;
    _objects["enemies"][2].second.y2 += _move_enemy[2] * 10;
    _objects["enemies"][3].second.y1 += _move_enemy[3] * 10;
    _objects["enemies"][3].second.y2 += _move_enemy[3] * 10;
    if (_objects["enemies"][0].second.x1 <= 120 || _objects["enemies"][0]
    .second.x1 >= 880)
        _move_enemy[0] *= -1;
    if (_objects["enemies"][1].second.x1 <= 120 || _objects["enemies"][1]
    .second.x1 >= 880)
        _move_enemy[1] *= -1;
    if (_objects["enemies"][2].second.y1 <= 120 || _objects["enemies"][2]
    .second.y1 >= 780)
        _move_enemy[2] *= -1;
    if (_objects["enemies"][3].second.y1 <= 120 || _objects["enemies"][3]
    .second.y1 >= 780)
        _move_enemy[3] *= -1;
}

void Solarfox::create_enemy_projectile(int enemy)
{
    object_creation_data *projectile_data = fill_data("x", SPRITE,
                                                  "assets/block_snake.png",
                                                  "magenta");
    pos projectile_pos = _objects["enemies"][enemy].second;
    void *projectile_obj = lib->createObject(projectile_data);
    _objects["enemy_projectiles"].emplace_back(*create_triple(projectile_data,
                                                            projectile_pos,
                                                            projectile_obj));

    std::pair<int, int> tmp;
    if (enemy == 0)
    {
        tmp.first = 0;
        tmp.second = 1;
    }
    else if (enemy == 1)
    {
        tmp.first = 0;
        tmp.second = -1;
    }
    else if (enemy == 2)
    {
        tmp.first = 1;
        tmp.second = 0;
    }
    else if (enemy == 3)
    {
        tmp.first = -1;
        tmp.second = 0;
    }
    _move_projectile.emplace_back(tmp);
}

void Solarfox::move_enemy_projectile()
{
    for (int i = 0; i < _objects["enemy_projectiles"].size(); i += 1) {
         _objects["enemy_projectiles"][i].second.x1 += _move_projectile[i]
             .first;
        _objects["enemy_projectiles"][i].second.x2 += _move_projectile[i]
            .first;
        _objects["enemy_projectiles"][i].second.y1 += _move_projectile[i]
            .second;
        _objects["enemy_projectiles"][i].second.y2 += _move_projectile[i]
            .second;
    }
}

void Solarfox::create_enemy_clocks()
{
    std::chrono::steady_clock::time_point t = std::chrono::steady_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::microseconds>(t -
        _last_tick).count();

    _last_enemy_shot.emplace_back(std::chrono::steady_clock::now());
    if (elapsed > 500000)
        _last_enemy_shot.emplace_back(std::chrono::steady_clock::now());
    if (elapsed > 1000000)
        _last_enemy_shot.emplace_back(std::chrono::steady_clock::now());
    if (elapsed > 1500000) {
        _last_enemy_shot.emplace_back(std::chrono::steady_clock::now());
        _created_clocks = true;
    }
}

